<template>
  <Header />
  <div class="p-4">
    <slot />
  </div>
  <Footer />
</template>
