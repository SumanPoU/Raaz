<template>
  <footer class="p-4 bg-gray-50">
    <span>&copy;RAZZA 2023, All rights reserved.</span>
  </footer>
</template>
