from django.apps import AppConfig


class AppCitizenDataConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'app_citizen_data'
